-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 01 Oca 2024, 09:37:00
-- Sunucu sürümü: 10.4.18-MariaDB
-- PHP Sürümü: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `obs`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `akademik_takvim`
--

CREATE TABLE `akademik_takvim` (
  `klavuz` int(10) NOT NULL,
  `Takvim_adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Başlangıç_tarihi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Bitiş_Tarihi` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `akademik_takvim`
--

INSERT INTO `akademik_takvim` (`klavuz`, `Takvim_adı`, `Başlangıç_tarihi`, `Bitiş_Tarihi`) VALUES
(1, 'Yeni Öğrenci Danışman Onay', '02.10.2023', '03.11.2023'),
(2, 'Ders Kayıt', '02.10.2023', '03.11.2023'),
(3, 'Danışman Onay', '18.09.2023', '03.11.2023'),
(4, 'Ara Sınav Not Giriş', '13.11.2023', '29.12.2023'),
(5, 'Ara Sınav Notlarının Öğrenciye Yayınlanması', '13.11.2023', '29.12.2023'),
(6, 'Final sınavı', '13.12.2023', '29.12.2023');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `alinan_dersler`
--

CREATE TABLE `alinan_dersler` (
  `klavuz` int(10) NOT NULL,
  `Ders Kodu` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Kredi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `T+U` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `AKTS` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Sinif` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Z/S` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Program` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Dil` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `ogretim_elemani` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `alinan_dersler`
--

INSERT INTO `alinan_dersler` (`klavuz`, `Ders Kodu`, `Ders Adı`, `Kredi`, `T+U`, `AKTS`, `Sinif`, `Z/S`, `Program`, `Dil`, `ogretim_elemani`) VALUES
(1, 'ORTL161', 'Atatürk İlkeleri ve İnkılap Tarihi-I', '2', '2+0', '2', '1', 'Z', 'Ortak Ders Programı', 'Türkçe', 'Öğr.Gör.Dr. EKİMAY MAHMUT'),
(3, 'MBBL013', 'Ayrık Matematik', '3', '3+0', '2', '3', 'Z', 'Ortak Ders Programı', 'Türkçe', 'Dr.Öğretim Üyesi BÜLENT ASİ'),
(4, 'BLML765	', 'Diferansiyel Denklemler', '5', '5+0', '5', '1', 'Z', 'Ortak Ders Programı', 'Türkçe', 'Dr.Öğretim Üyesi BÜLENT ASİ'),
(5, 'BLML665', 'Elektronik-I', '5', '5+0', '3', '3', 'Z', 'Ortak Ders Programı', 'Türkçe', 'Öğr.Gör.Dr. EKİMAY MAHMUT'),
(6, 'ORTL161', 'Veritabanı yönetim sistemleri', '4', '4+0', '2', '3', 'Z', 'Ortak Ders Programı', 'Türkçe', 'Dr.Öğretim Üyesi Pınar Atas'),
(7, 'BLML161', 'Algoritma ve Programlama-I', '0', '2+0', '0', '2', 'Z', 'Ortak Ders Programı	', 'Türkçe', 'Dr.Öğretim Üyesi Pınar Atas'),
(8, 'BLML465', 'Bilgisayar Mühendisliğinde Proje	', '4', '4+0', '5', '4', 'Z', 'Ortak Ders Programı	', 'Türkçe', 'Öğr.Gör.Dr.Aziz Ova'),
(9, 'BLML565', 'İleri Nesne Tabanlı Programlama	', '4', '4+0', '5', '1', 'Z', 'Ortak Ders Programı	', 'Türkçe', 'Öğr.Gör.Dr. Ahmet Ay'),
(10, 'BLML412', 'Veri Yapıları', '5', '2+0', '4', '2', 'Z', 'Ortak Ders Programı	', 'Türkçe	', 'Öğr. Gör. Dr.FARUK BULUT'),
(11, 'BLML212', 'Nesne Tabanlı Programlama', '4', '1+0', '2', '2', 'Z', 'Ortak Ders Programı	', 'Türkçe	', 'Öğr. Gör. Dr.FARUK BULUT'),
(12, 'BLML912', 'Olasılık ve İstatistik	', '2', '2+0', '2', '2', 'Z', 'Ortak Ders Programı	', 'Türkçe	', 'Öğr. Gör. Dr.Esra Ulu'),
(13, 'BLML365', 'Makine Öğrenmesi', '3', '2+0', '4', '3', 'Z', 'Ortak Ders Programı	', 'Türkçe	', 'Öğr.Gör.Dr. SEDAT KURU\r\n');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ders_programi`
--

CREATE TABLE `ders_programi` (
  `klavuz` int(10) NOT NULL,
  `Saat` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Derslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Öğretim_Elemanı` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ders_programi`
--

INSERT INTO `ders_programi` (`klavuz`, `Saat`, `Ders Adı`, `Derslik`, `Öğretim_Elemanı`) VALUES
(1, 'PAZARTESİ-09:00-11:50', 'İşletim Sistemleri', 'TY.3.318 [35]', 'Dr.Öğretim Üyesi FUAT CANDAN\r\n'),
(2, 'PAZARTESİ-09:00-11:50', 'İşletim Sistemleri', 'TY.3.318 [35]', 'Dr.Öğretim Üyesi FUAT CANDAN\r\n'),
(3, 'PAZARTESİ-13:00-16:50', 'Veri Haberleşmesi ve Bilgisayar Ağları', 'TY.2.218', 'AZİZE OVA'),
(4, 'SALI-09:00-13:50', 'Mikroişlemciler ve Lab.', 'TY.1.150 [19]', 'Dr.Öğretim Üyesi ÜNAL KÜLLÜ'),
(5, 'SALI-14:00-16:50', 'Makine Öğrenmesi', 'TY.0.Z48[60]	', 'Prof. Dr. MUSTAFA EMRE AYDEMİR\r\n'),
(6, 'PERŞEMBE-09:00-16.50	', 'Veritabanı Yönetim Sistemleri', 'TY.0.Z09 PC LAB[35]', 'Dr.Öğretim Üyesi PINAR ATAR'),
(7, 'CUMA-14:00-16:50', 'Veri Yapıları', 'UZEM100[130]	', 'Dr.Öğretim Üyesi FURKAN GÖZÜKAYA');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `devamızlık`
--

CREATE TABLE `devamızlık` (
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `T+U` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Krd` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Toplam Devamsızlık Saat` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `devamızlık`
--

INSERT INTO `devamızlık` (`Ders Adı`, `T+U`, `Krd`, `Toplam Devamsızlık Saat`) VALUES
('Veri Yapıları', '2', '5', '(Teorik:1) (Uygulama:1)'),
('Nesne Tabanlı Programlama', '4', '5', '(Teorik:0) (Uygulama:0)	'),
('Elektronik-I', '5', '3', '(Teorik:3) (Uygulama:0)	'),
('İşletim Sistemleri	', '3', '3', '(Teorik:1) (Uygulama:0)	'),
('Ayrık Matematik', '4', '2', '(Teorik:0) (Uygulama:0)	'),
('Diferansiyel Denklemler', '3', '2', '(Teorik:7) (Uygulama:0)	'),
('Makine Öğrenmesi	', '2', '2', '(Teorik:2) (Uygulama:0)	'),
('Olasılık ve İstatistik', '2', '3', '(Teorik:0) (Uygulama:0)	');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `donem_ortalaması`
--

CREATE TABLE `donem_ortalaması` (
  `Dönem Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Aldığı Ders Sayısı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Toplam Kredi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Toplam AKTS` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Dönem Ortalaması` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Genel Not Ortalaması` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `donem_ortalaması`
--

INSERT INTO `donem_ortalaması` (`Dönem Adı`, `Aldığı Ders Sayısı`, `Toplam Kredi`, `Toplam AKTS`, `Dönem Ortalaması`, `Genel Not Ortalaması`) VALUES
('2021-2022 Güz Dönemi	', '7', '23', '30', '2.95', '2.95'),
('2021-2022 Güz Dönemi	', '7', '23', '30', '2.95', '2.95'),
('2021-2022 Bahar Dönemi', '6', '22', '30', '2.75', '2.85'),
('2022-2023 Güz Dönemi	', '7', '20', '30', '1.17', '2.28'),
('2022-2023 Bahar Dönemi', '8', '24', '30', '2.65', '2.30'),
('2023-2024 Güz Dönemi	', '7', '23', '30', '2.95', '2.95');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `not_listesi`
--

CREATE TABLE `not_listesi` (
  `klavuz` int(10) NOT NULL,
  `Ders Kodu` int(255) NOT NULL,
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Durum` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Sinav_notu` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Ders_durum` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `not_listesi`
--

INSERT INTO `not_listesi` (`klavuz`, `Ders Kodu`, `Ders Adı`, `Durum`, `Sinav_notu`, `Ders_durum`) VALUES
(1, 201, 'Veri Yapıları', '1', 'Vize:28  ', 'G'),
(2, 203, 'Nesne Tabanlı Programlama', '1', 'Vize:61', 'G'),
(3, 203, 'Elektronik-I', '0', 'Vize:16', 'K'),
(4, 205, 'Ayrık Matematik', '0', 'Vize:18', 'K'),
(5, 204, 'Diferansiyel Denklemler', '1', 'Vize:41', 'G'),
(6, 221, 'Olasılık ve İstatistik', '1', 'Vize:17', 'G');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrenci_bilgileri`
--

CREATE TABLE `ogrenci_bilgileri` (
  `klavuz` int(10) NOT NULL,
  `Ad` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Soyad` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `okul_no` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Dogum_tarihi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `telefon` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `adres` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Kayıt_tarihi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Donem` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `bolum` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `danışman` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `AGNO` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Sınıf` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `danısman_mail` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ogrenci_bilgileri`
--

INSERT INTO `ogrenci_bilgileri` (`klavuz`, `Ad`, `Soyad`, `okul_no`, `Dogum_tarihi`, `telefon`, `adres`, `Kayıt_tarihi`, `Donem`, `bolum`, `danışman`, `AGNO`, `Sınıf`, `danısman_mail`) VALUES
(1, 'Sümeyye', 'Gülçeken', '210309022', '23/10/2001', '05524581739', 'Adnan kahveci mah. beykent/Beylikdüzü', '21/09/2021', '2023-2024', 'Bilgisayar Mühendisliği', 'Pınar Atas', '2.87', '3', 'pytrndj@gmail.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `program_dersleri`
--

CREATE TABLE `program_dersleri` (
  `klavuz` int(10) NOT NULL,
  `Ders Kodu` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Sınıf` int(10) NOT NULL,
  `U` int(10) NOT NULL,
  `L` int(10) NOT NULL,
  `T` int(10) NOT NULL,
  `Z` int(10) NOT NULL,
  `KRD` int(10) NOT NULL,
  `AKTS` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `program_dersleri`
--

INSERT INTO `program_dersleri` (`klavuz`, `Ders Kodu`, `Ders Adı`, `Sınıf`, `U`, `L`, `T`, `Z`, `KRD`, `AKTS`) VALUES
(1, 'BLML161', 'Algoritma ve Programlama-I', 2, 0, 2, 1, 0, 0, 0),
(2, 'MBBL013', 'Ayrık Matematik', 2, 0, 2, 1, 3, 4, 6),
(3, 'BLML465', 'Bilgisayar Mühendisliğinde Özel Proje	', 4, 0, 0, 3, 2, 4, 5),
(5, 'BLML765', 'Diferansiyel Denklemler', 2, 2, 1, 3, 2, 4, 5),
(6, 'BLML665', 'Elektronik-I', 3, 5, 4, 3, 2, 4, 5),
(7, 'BLML565', 'İleri Nesne Tabanlı Programlama	', 1, 2, 1, 3, 2, 4, 5);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sinav_takvimi`
--

CREATE TABLE `sinav_takvimi` (
  `klavuz` int(10) NOT NULL,
  `Ders Kodu` int(11) NOT NULL,
  `Ders Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Sınav _Adı` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `Tarihi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `E.Oran` int(50) NOT NULL,
  `Derslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `sinav_takvimi`
--

INSERT INTO `sinav_takvimi` (`klavuz`, `Ders Kodu`, `Ders Adı`, `Sınav _Adı`, `Tarihi`, `E.Oran`, `Derslik`) VALUES
(2, 472, 'Makine Öğrenmesi', 'Yarıyıl Sonu Sınavı', '09.01.2024 14:00', 60, '203'),
(3, 572, 'Veri Haberleşmesi ve Bilgisayar Ağları', 'Yarıyıl Sonu Sınavı', '09.01.2024 09:30', 70, '206'),
(4, 342, 'Nesne Tabanlı Programlama', 'Yarıyıl Sonu Sınavı', '11.01.2024 14:00', 60, '201'),
(5, 342, 'Veritabanı Yönetim Sistemleri', 'Yarıyıl Sonu Sınavı', '15.01.2024 13:00', 70, '205'),
(6, 342, 'Veri Yapıları', 'Yarıyıl Sonu Sınavı', '19.01.2024 15:00', 50, '211'),
(7, 342, 'Mikroişlemciler ve Lab.	', 'Yarıyıl Sonu Sınavı', '8.01.2024 15:00', 50, '218'),
(8, 311, 'İşletim Sistemleri	', 'Yarıyıl Sonu Sınavı', '22.01.2024 15:00', 50, '211');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `akademik_takvim`
--
ALTER TABLE `akademik_takvim`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `alinan_dersler`
--
ALTER TABLE `alinan_dersler`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `ders_programi`
--
ALTER TABLE `ders_programi`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `not_listesi`
--
ALTER TABLE `not_listesi`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `ogrenci_bilgileri`
--
ALTER TABLE `ogrenci_bilgileri`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `program_dersleri`
--
ALTER TABLE `program_dersleri`
  ADD PRIMARY KEY (`klavuz`);

--
-- Tablo için indeksler `sinav_takvimi`
--
ALTER TABLE `sinav_takvimi`
  ADD PRIMARY KEY (`klavuz`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ogrenci_bilgileri`
--
ALTER TABLE `ogrenci_bilgileri`
  MODIFY `klavuz` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `akademik_takvim`
--
ALTER TABLE `akademik_takvim`
  ADD CONSTRAINT `akademik_takvim_ibfk_1` FOREIGN KEY (`klavuz`) REFERENCES `not_listesi` (`klavuz`) ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `not_listesi`
--
ALTER TABLE `not_listesi`
  ADD CONSTRAINT `not_listesi_ibfk_1` FOREIGN KEY (`klavuz`) REFERENCES `akademik_takvim` (`klavuz`) ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `ogrenci_bilgileri`
--
ALTER TABLE `ogrenci_bilgileri`
  ADD CONSTRAINT `ogrenci_bilgileri_ibfk_1` FOREIGN KEY (`klavuz`) REFERENCES `ders_programi` (`klavuz`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
